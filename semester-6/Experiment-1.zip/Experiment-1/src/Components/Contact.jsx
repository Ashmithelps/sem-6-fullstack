function Contact() {
  return (
    <div>
      <h2>Contact Page</h2>
      <p>Email:thakurashmit20@gmail.com</p>
      <p>Phone Number: XXXXXXXXX</p>

    </div>
  );
}

export default Contact;